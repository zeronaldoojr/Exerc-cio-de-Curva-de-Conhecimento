﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LanternaTeste
{
    public partial class Form1 : Form
    {
        Lanterna l = new Lanterna();
        Bateria b = new Bateria();
        int contando;
        int tempo = 100;
        
        public Form1()
        {
            InitializeComponent();
            var teste = b.GetCarga();
            textBox1.Text = teste+"%";
            var iniciaBateria = l.GetStatus();
            if(iniciaBateria == false)
            {
           textBox2.Text = "Desligada";
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            

        }
        private void button1_Click(object sender, EventArgs e)
        {
            var ligaLanterna = l.GetStatus();
            ligaLanterna = true;
            var teste = b.GetCarga();
            timer1 = new System.Windows.Forms.Timer();
            
            contando = ++contando;
            if (contando % 2 == 0)
            {
                ligaLanterna = false;
                if (ligaLanterna == false)
                {
                    textBox2.Text = "Desligada";
                    timer1.Stop();
                  
                }

            }
            else
            {
                ligaLanterna = true;
                timer1.Tick += new EventHandler(count_down);
                timer1.Interval = 1000;
                timer1.Start();
                textBox2.Text = "Ligada";

            }
           
          
           
          
        }
        private void count_down(object sender, EventArgs e)
        {
            
            var ligaLanterna = l.GetStatus();
            
            if (tempo == 0 || contando % 2 == 0)
            {
                timer1.Stop();
                textBox2.Text = "Desligada";

            }
            else if (tempo > 0)
            {
                tempo--;
                textBox1.Text = tempo+"%".ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tempo = 100;
            textBox1.Text = tempo + "%".ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }
    }

    
}
