﻿using System;

namespace Multiplos
{
    class Program
    {
        static void Main(string[] args)
        {
            Numero n = new Numero();
            Console.WriteLine("Digite um numero natural: ");
            n.SetNumeroRecebido(int.Parse(Console.ReadLine()));
            var numeroRecebido = n.GetNumeroRecebido();
            int soma = 0;
            const int div3 = 3;
            const int div5 = 5;
            
              if (numeroRecebido%div3 == 0 || numeroRecebido%div5 == 0)
            {
                for (int i = 0; i <= numeroRecebido; i++)
                {
                    soma = soma + i;
                }
                   Console.WriteLine("A soma dos numero é:" + soma);
                   Console.ReadKey(); 
            }
            else
            {
                Console.WriteLine("O numero informado não é multiplo de 3 nem de 5"+ numeroRecebido);
                Console.ReadKey();
            }
            
        }
    }
}
