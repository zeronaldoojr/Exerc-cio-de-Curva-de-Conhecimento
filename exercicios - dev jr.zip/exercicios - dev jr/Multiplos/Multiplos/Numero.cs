﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplos
{
    class Numero
    {
        private int NumeroRecebido;

        public int GetNumeroRecebido()
        {
            return this.NumeroRecebido;
        }
        public void SetNumeroRecebido(int numeroRecebido) 
        {
            this.NumeroRecebido = numeroRecebido;
        }
    }
}
