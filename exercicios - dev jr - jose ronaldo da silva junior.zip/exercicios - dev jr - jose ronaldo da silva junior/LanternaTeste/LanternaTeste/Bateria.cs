﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanternaTeste
{
    class Bateria
    {
     private int carga = 100;

        public int GetCarga()
        {
            return this.carga;
        }
        public void SetCarga(int carga)
        {
            this.carga = carga;
        }
    }
}
