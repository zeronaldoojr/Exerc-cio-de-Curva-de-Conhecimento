﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LanternaTeste
{
    class Lanterna
    {
       private bool Status;

        public bool GetStatus()
        {
            return this.Status;
        }
        public void SetStatus(bool status)
        {
            this.Status = status;
        }
    }
}
